const yet=[
    {
        "title":"Ancient Biggest Karnataka Fort",
        "pics":"images\\fort1.jpg"
    },
    {
        "title":"Nisagara Bhraman Karnataka Fort",
        "pics":"images\\fort2.jpg"
    },
    {
        "title":"Belgaum Karnataka Fort",
        "pics":"images\\fort3.jpg"
    }
]

export {yet}