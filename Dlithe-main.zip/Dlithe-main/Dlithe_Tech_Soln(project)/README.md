This project is a simple interactive webpage for a Technical Service company, "Dlithe Technical Solutions".
This project is created using React app which was taught to us during the training period of the Frontend Internship offered by Dlithe.
In this project we can see a webpage consisting of the name of the company, a navigation bar containing options to Login, Signup or to go back to Home.
If we scroll below, we get a brief glimpse at the services offered by the company such as PC repair, Data recovery,etc
At the end we can see a footer containing other contact information and other details of the company.
Enclosed below are some photos of the project to get an idea of how it works.

![image 1](https://raw.githubusercontent.com/anshul-shetty/Dlithe/main/Dlithe_Tech_Soln(project)/src/assets/Screenshot%20(1).png)

![image 2](https://raw.githubusercontent.com/anshul-shetty/Dlithe/main/Dlithe_Tech_Soln(project)/src/assets/Screenshot%20(2).png)

![image 3](https://raw.githubusercontent.com/anshul-shetty/Dlithe/main/Dlithe_Tech_Soln(project)/src/assets/Screenshot%20(3).png)

![image 4](https://raw.githubusercontent.com/anshul-shetty/Dlithe/main/Dlithe_Tech_Soln(project)/src/assets/Screenshot%20(4).png)